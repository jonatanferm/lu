function ind=findcross(x,v)
%FINDCROSS Finds indices to level v up and downcrossings of a vector
%
%  CALL: ind = findcross(x,v);
%
%        x  = vector with sampled values.
%
%        v  = level v. (Default 0). 
%
%	ind = indices to the crossings in the original sequence x.
%
% Example
%  v = 0.75
%  t = linspace(0,7*pi,250); x = sin(t);
%  ind = findcross(x,v)
%  plot(t,x,'.',t(ind),x(ind),'r.', t, ones(size(t))*v)
%
% See also dat2crossind, crossdef

% there is also a mex version of this which is much faster,
% which is run instead if compiled and located before this file 
% in the MATLAB search path.

% Tested on: Matlab 5.3, 5.2 5.1

% History:
% revised pab Feb2004
% revised pab 13.06.2001
% -Added example
% - fixed a bug: this .m file previosly only returned zero crossings.
% by pab 17.07.1997

if nargin<2|isempty(v),
  v=0;
end
xn = x(:);
n  =length(xn);

% Trick to avoid turning points on the crossinglevel.
ind = find(xn(2:(n-1))==v);
for ix=ind.',
   xn(ix+1)=xn(ix);
end

% indices to local level crossings ( without turningpoints)
ind = find( (((xn(1:(n-1))>=v) .* (xn(2:n)<v)) | ...
      ((xn(1:(n-1))<=v) .* (xn(2:n) > v))) )  ;


return


