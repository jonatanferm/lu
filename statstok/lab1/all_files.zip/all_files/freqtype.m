function ftype=freqtype(S)
% FREQTYPE returns the frequency type of a Spectral density struct.
%
% CALL: ftype = freqtype(S)
%
%  ftype = 'f' if frequency is given in Hz
%          'w' if frequency is given in rad/s
%          'k' if a wave number spectrum is given
%      S = spectral density struct
%
% See also  datastructures

% History:
%  revised pab 17.02.2000
% - updated header
% revised pab 24.01.2000
%  - added check if field exist
% by pab 

names=fieldnames(S); 
ind=find(strcmp(names,'f')+strcmp(names,'w')+strcmp(names,'k')); %options are 'f' and 'w' and 'k' 
if isempty(ind)
  warning('This is not a spectral density structure')
  ftype=[];
else
  ftype=lower(names{ind}); 
end